/* 
 * File:   main_Part_3.c
 * Author: Burned Yams
 *
 * Created on February 7, 2020, 8:24 PM
 */
#include <BOARD.h>
#include <serial.h>
#include <CAPTOUCH.h>
#include <timers.h>
#include <AD.h>
#include <stdio.h>
#include <stdlib.h>

/*
 * 
 */
int main(int argc, char** argv) {
    // These variables store the running time and the ADC value from the bridge
    int time, level = 0;
    
    // This variable store the return from CAPTOUCH_IsTouched())
    char touch;
    
    // This variable store whether the device is currently being touched or not
    char state = 0;
    
    // Initialze the functions
    BOARD_Init();
    TIMERS_Init();
    CAPTOUCH_Init();
    AD_Init();
    
    // Add the pin for the bridge ADC
    AD_AddPins(AD_A1);
    
    // Initialize the timer variable
    time = TIMERS_GetMilliSeconds();
    
    while (1) {
        /* If new data is ready, read the ADC value. Update the variable if it 
         * is a maximum
         */ 
        if (AD_IsNewDataReady()) {
            if (AD_ReadADPin(AD_A1) > level) {
                level = AD_ReadADPin(AD_A1);
            }
        }
        
        /* Every 100ms check if the ADC value is above threshold or if the 
         * frequency is below threshold
         */ 
        if ((TIMERS_GetMilliSeconds()) - time > 100) {
            touch = CAPTOUCH_IsTouched();
            printf("%d ", level);
            if ((level > 300 || touch == TRUE) && state == 0) {
                printf("(TOUCHED) ");
                state = 1;
            }
            if (level < 300 && touch == FALSE && state == 1) {
                printf("(no touch) ");
                state = 0;
            }
            
            // Reset the ADC value and update the time
            level = 0;
            time = TIMERS_GetMilliSeconds();
        }
    }

    return (EXIT_SUCCESS);
}

