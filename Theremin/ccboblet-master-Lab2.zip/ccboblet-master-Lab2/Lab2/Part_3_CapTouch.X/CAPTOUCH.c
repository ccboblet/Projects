/*
 * File:   CAPTOUCH.c
 * Author: ccboblet
 *
 * Created on February 7, 2020, 9:27 AM
 */

#include "BOARD.h"
#include <xc.h>
#include <sys/attribs.h>
#include <AD.h>
#include <timers.h>

#define threshold 0x4aa

static char touched;

char CAPTOUCH_Init(void) {
    // following block inits the timer
    T2CON = 0;
    T2CONbits.TCKPS = 0b011;
    PR2 = 0xFFFF;
    T2CONbits.ON = 1;

    //this block inits input capture
    IC4CON = 0;
    IC4CONbits.ICTMR = 1;
    IC4CONbits.ICM = 0b010;

    IFS0bits.IC4IF = 0;
    IPC4bits.IC4IP = 7;
    IEC0bits.IC4IE = 1;
    IC4CONbits.ON = 1;
    // whatever else you need to do to initialize your module
    touched = 0;
}

char CAPTOUCH_IsTouched(void) {
    return touched;
}

void __ISR(_INPUT_CAPTURE_4_VECTOR) InputCapture_Handler(void) {
    /* State records how many samples have been taken. Count records how many 
     * samples have been above threshold
     */ 
    static char state = 0, count = 0;
    
    // This variable holds the last recorded time
    static int times;
    
    // This variable holds the current time
    int temp;
    
    IFS0bits.IC4IF = 0;
    // IC4BUF contains the timer value when the rising edge occurred.

    // Read the timer value
    temp = IC4BUF;

    // Test if samples are above threshold for 50 iterations
    if (state < 50) {
        if ((temp - times) > threshold) {
            count += 1;
        }
        state += 1;
        
        // After fifty iterations test if more than 2 have been above threshold
    } else {
        if (count > 2) {
            touched = 1;
        } else {
            touched = 0;
        }
        
        // Reset sample and threshold counts
        count = 0;
        state = 0;
    }
    
    // Update the past time
    times = temp;
}