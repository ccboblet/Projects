/* 
 * File:   main_Part_1.c
 * Author: Burned Yams
 *
 * Created on February 5, 2020, 5:25 PM
 */
#include <BOARD.h>
#include <AD.h>
#include <pwm.h>
#include <serial.h>
#include <QEI.h>
#include <timers.h>
#include <stdio.h>
#include <stdlib.h>

/*
 * This program changes the color of an LED depending on the amount of steps a 
 * QEI has been turned.
 */
int main(int argc, char** argv) {
    // These variables hold the angle of the QEI and a running count of a timer
    int angle = 0, time = TIMERS_GetMilliSeconds();
    
    /* These variables are used to set the frequency of the PWM going to each 
     * of the colored LEDs
    */
    int red, blue, green;
    
    // Initialize the functions
    BOARD_Init();
    QEI_Init();
    TIMERS_Init();
    PWM_Init();

    // Add the pins for PWM
    PWM_AddPins(PWM_PORTZ06);
    PWM_AddPins(PWM_PORTY12);
    PWM_AddPins(PWM_PORTY10);
    PWM_SetDutyCycle(PWM_PORTZ06, 0);
    PWM_SetDutyCycle(PWM_PORTY12, 1000);
    PWM_SetDutyCycle(PWM_PORTY10, 1000);

    while (1) {
        // If 200ms have passed print the angle and update the colors
        if (QEI_GetPosition() != angle) {
            
            // Update the timer value
            time = TIMERS_GetMilliSeconds();
            
            // Get, scale, and print the angle
            angle = QEI_GetPosition();
            angle = (angle - 1000)*15;
            printf("%d \n", angle);

            // Copy the angle into temporary variables
            red = angle;
            green = angle;
            blue = angle;
            
            /* Calculate the frequency of the red signal. Red is on between 
             * -240 and 120
             */
            if (angle <= (-240)) {
                red += 360;
            }
            if (angle >= 240) {
                red -= 360;
            }
            if (red < 0) {
                red = red * (-1);
            }
            if (red > 120) {
                red = 1000;
            } else {
                red = red * 8;
            }
            PWM_SetDutyCycle(PWM_PORTZ06, red);
            
            /* Calculate the frequency of the green signal. Green is on between 
             * 0 and 240.
             */ 
            if (angle >= 0) {
                green -= 120;
            }
            if (angle <= (-120)) {
                green += 240;
            }
            if (angle < 0 && angle > (-120)) {
                green = 1000;
            }
            if (green < 0) {
                green = green * (-1);
            }
            if (green > 120) {
                green = 1000;
            } else {
                green = green * 8;
            }
            PWM_SetDutyCycle(PWM_PORTY12, green);

            /* Calculate the frequency of the blue signal. Blue is on between 
             * 120 and 360.
             */
            if (angle <= 0) {
                blue += 120;
            }
            if (angle >= 120) {
                blue -= 240;
            }
            if (angle > 0 && angle < 120) {
                blue = 1000;
            }
            if (blue < 0) {
                blue = blue * (-1);
            }
            if (blue > 120) {
                blue = 1000;
            } else {
                blue = blue * 8;
            }
            PWM_SetDutyCycle(PWM_PORTY10, blue);
        }
    }

    return (EXIT_SUCCESS);
}

