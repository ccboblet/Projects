/*
 * File:   QEI.c
 * Author: ccboblet
 *
 * Created on February 5, 2020, 9:27 AM
 */

#include "BOARD.h"
#include <xc.h>
#include <sys/attribs.h>

/* This variable holds the current count of the QEI. The initial count is set 
 * to 1000 to give room for negative degrees
 */
static int count = 1000;

// This function initializes the interrupt.
char QEI_Init(void) {
    // INIT Change notify
    CNCONbits.ON = 1; // Change Notify On
    CNENbits.CNEN15 = 1; //enable one phase
    CNENbits.CNEN16 = 1; //enable other phase
    int temp = PORTD; // this is intentional to ensure a interrupt occur immediately upon enabling
    IFS1bits.CNIF = 0; // clear interrupt flag
    IPC6bits.CNIP = 1; //set priority
    IPC6bits.CNIS = 3; // and sub priority
    IEC1bits.CNIE = 1; // enable change notify
}

// This function returns the current count
int QEI_GetPosition(void) {
    return count;
}

// This function resets the count to its initial value
void QEI_ResetPosition(){
    count = 1000;
}

/* This interrupt detects the rising edge of pin 37 and then checks the state 
 * of pin 36. If pin 36 is high, decrement. If pin 36 is low, increment. The 
 * count will roll over if it changes by more than 24.
 */
void __ISR(_CHANGE_NOTICE_VECTOR) ChangeNotice_Handler(void) {
    // These variables hold the current and previous states of Pin 36
    static char readPort = 0;
    static char states = 0;
    readPort = PORTD; // this read is required to make the interrupt work
    IFS1bits.CNIF = 0;
    
    // If the previous state of pin 37 was low, it could be a rising edge
    if ((states & 0x80) == 0x00) {
        // If pin 37 is now high, check pin 36
        if (readPort & 0x80) {
            // If pin 36 is high, decrement else increment
            if (readPort & 0x40) {
                count -= 1;
            } else {
                count += 1;
            }
            // roll over if the count has changed by 24
            if (count >= 1024 || count <= 976) {
                count = 1000;
            }
        }
    }
    // Update the states variable
    states = readPort & 0x80;

}