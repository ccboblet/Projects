/* 
 * File:   main_Ping.c
 * Author: Burned Yams
 *
 * Created on February 5, 2020, 7:51 PM
 */
#include <BOARD.h>
#include <serial.h>
#include <PING.h>
#include <ToneGeneration.h>
#include <stdio.h>
#include <stdlib.h>

/*
 * 
 */
int main(int argc, char** argv) {
    // These variables hold the running count of time and distance detected
    int times, distance;

    // Initialize functions
    BOARD_Init();
    PING_Init();
    ToneGeneration_Init();
    TIMERS_Init();
    times = TIMERS_GetMilliSeconds();
    while (1) {
        // Every 500ms check the distance and update the frequency
        if ((TIMERS_GetMilliSeconds() - times) > 500) {
            
            // Get the distance and print
            distance = PING_GetDistance();
            printf("%d ", distance);
            
            // Change the frequency of sound
            ToneGeneration_ToneOff();
            ToneGeneration_SetFrequency(TONE_293 + distance * 10);
            ToneGeneration_ToneOn();
            times = TIMERS_GetMilliSeconds();
        }
    }

    return (EXIT_SUCCESS);
}

