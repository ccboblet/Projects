/*
 * File:   PING.c
 * Author: ccboblet
 *
 * Created on February 5, 2020, 9:27 AM
 */

#include "BOARD.h"
#include <xc.h>
#include <sys/attribs.h>
#include <timers.h>

// These variables hold the time of flight and a running timer respectively.
static int count = 0, time = 0;

// Initialize the interrupts
char PING_Init(void) {
    // following block inits the timer
    T4CON = 0;
    T4CONbits.TCKPS = 0b110;
    PR4 = 0xFFFF; // this is not the timer value wanted
    T4CONbits.ON = 1;
    IFS0bits.T4IF = 0;
    IPC4bits.T4IP = 3;
    IEC0bits.T4IE = 1;

    // following block inits change notify
    CNCONbits.ON = 1; // Change Notify On
    CNENbits.CNEN14 = 1;
    int temp = PORTD; // this is intentional to ensure a interrupt occur immediately upon enabling
    IFS1bits.CNIF = 0; // clear interrupt flag
    IPC6bits.CNIP = 1; //set priority
    IPC6bits.CNIS = 3; // and sub priority
    IEC1bits.CNIE = 1; // enable change notify
    //Anything else that needs to occur goes here
    
    // Set the timer to interupt every 14us
    PR4 = 0xA;
    
    // Set RD3 to be an output
    TRISDbits.TRISD3 = 0;
}

// Scale the time of flight to get distance and return the distance in cm
unsigned int PING_GetDistance(void) {
    count = count>>6;
    return count;
}

// Subtract the offset from the time of flight and return the time of flight in us
unsigned int PING_GetTimeofFlight(void) {
    count = count-87;
    return count;
}

// Interrupt when the Echo signal changes
void __ISR(_CHANGE_NOTICE_VECTOR) ChangeNotice_Handler(void) {
    static char readPort = 0;
    readPort = PORTD; // this read is required to make the interrupt work
    IFS1bits.CNIF = 0;
    // Start the timer on a rising edge
    if ((PORTD & 0x20) && (time == 0)) {
        time = TIMERS_GetMicroSeconds();
    }
    // Stop the timer on a falling edge
    if(!(PORTD & 0x20) && time){
        count = TIMERS_GetMicroSeconds() - time;
        time = 0;
    }

}

void __ISR(_TIMER_4_VECTOR) Timer4IntHandler(void) {
    IFS0bits.T4IF = 0;
    /* Output high on the trigger pin for 10us then set the interrupt to happen 
     * again in 60ms
     */ 
    if (LATDbits.LATD3) {
        LATDbits.LATD3 = 0;
        PR4 = 0x9470;
    } else {
        LATDbits.LATD3 = 1;
        PR4 = 0xA;
    }
}