/* 
 * File:   RoatationMatrix.h
 * Author: Colin Boblet
 *
 * Created on March 8, 2020
 */

#ifndef RotationMatrix_H
#define	RotationMatrix_H


/**
 * @Function RotMat_GetDegree(float DCM[3][3], int angles[3])
 * @param DCM - rotation matrix
 * @param angles - angles, yaw, pitch and roll of the rotation matrix
 * @return None
 * @brief Changes angles to match the rotation matrix
 * @author Colin Boblet*/
void RotMat_GetDegree(float DCM[3][3], int angles[3]);

/**
 * @Function RotMat_SimpleForward(float DCM[3][3], int w[3])
 * @param DCM - rotation matrix
 * @param w - angular rate of change
 * @return None
 * @brief Updates rotation matrix with angular change
 * @author Colin Boblet*/
void RotMat_SimpleForward(float DCM[3][3], int w[3]);

/**
 * @Function RotMat_Openloop(float DCM[3][3], int w[3])
 * @param DCM - rotation matrix
 * @param w - angular rate of change
 * @return None
 * @brief Updates rotation matrix with angular change
 * @author Colin Boblet*/
void RotMat_Openloop(float DCM[3][3], int w[3]);

/**
 * @Function RotMat_Closedloop(float DCM[3][3], int w[3])
 * @param DCM - rotation matrix
 * @param w - angular rate of change
 * @return None
 * @brief Updates rotation matrix with angular change
 * @author Colin Boblet*/
void RotMat_Closedloop(float DCM[3][3], float Bias[3], int w[3], float Accel[3], float Mag[3]);


#endif	/* MPU9250_H */

