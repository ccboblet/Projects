/* 
 * File:   RoatationMatrix.h
 * Author: Colin Boblet
 *
 * Created on March 8, 2020
 */

#include <RotationMatrix.h>
#include <math.h>

#define PI (3.141592653589793)
#define dt (0.02)
#define gyro_scale (4300)

/**
 * @Function RotMat_GetDegree(float DCM[3][3], int angles[3])
 * @param DCM - rotation matrix
 * @param angles - angles, yaw, pitch and roll of the rotation matrix
 * @return None
 * @brief Changes angles to match the rotation matrix
 * @author Colin Boblet*/
void RotMat_GetDegree(float DCM[3][3], int angles[3]) {
    int i;
    float cosp;

    // DCM[0][2] = -sin(pitch) so angles[1] becomes the pitch angle
    angles[1] = asin(-1 * DCM[0][2])*180 / PI;

    // This is a temporary value used to find the other angles
    cosp = cos(asin(-1 * DCM[0][2]));

    // Check if cos(pitch)==0 so you don't divide by zero
    if (fabs(cosp) > 0.01) {
        // Use the four quadrant atan function to extract the other angles
        angles[0] = atan2(DCM[0][1] / cosp, DCM[0][0] / cosp)*180 / PI;
        angles[2] = atan2(DCM[1][2] / cosp, DCM[2][2] / cosp)*180 / PI;
    } else {
        /* If cosp was close to zero, use the other angles (this works because 
         * sin(pitch) is close to +/- 1)
         */
        if (DCM[0][2] > 0) {
            angles[0] = atan2(DCM[2][1], DCM[2][0])*180 / PI;
            angles[2] = 0;
        } else {
            angles[0] = atan2(-DCM[2][1], -DCM[2][0])*180 / PI;
            angles[2] = 0;
        }
    }
}

/**
 * @Function RotMat_SimpleForward(float DCM[3][3], int w[3])
 * @param DCM - rotation matrix
 * @param w - angular rate of change
 * @return None
 * @brief Updates rotation matrix with angular change
 * @author Colin Boblet*/
void RotMat_SimpleForward(float DCM[3][3], int w[3]) {
    // Variables for for loops
    int i, j, k;

    // Float version of w
    float wt[3];

    // Temporary matrix for multiplication result
    float T[3][3];
    for (i = 0; i < 3; i++) {
        wt[i] = ((float) w[i]) / gyro_scale;
        for (j = 0; j < 3; j++) {
            T[i][j] = 0;
        }
    }

    // Cross product matrix
    float W[3][3] = {
        {0, -wt[2] * dt, wt[1] * dt},
        {wt[2] * dt, 0, -wt[0] * dt},
        {-wt[1] * dt, wt[0] * dt, 0}
    };

    // Matrix multiplication
    for (i = 0; i < 3; i++) {
        for (j = 0; j < 3; j++) {
            for (k = 0; k < 3; k++) {
                T[i][j] += W[i][k] * DCM[k][j];
            }
        }
    }

    // Add in the forward integration
    for (i = 0; i < 3; i++) {
        for (j = 0; j < 3; j++) {
            DCM[i][j] += T[i][j];
        }
    }
}

/**
 * @Function RotMat_Expo(float DCM[3][3], int w[3])
 * @param DCM - rotation matrix
 * @param w - angular rate of change
 * @return None
 * @brief Updates rotation matrix with angular change
 * @author Colin Boblet*/
void RotMat_Openloop(float DCM[3][3], int w[3]) {
    // Variables for for loops
    int i, j, k;

    // Sinc(norm/2) and cos(norm/2)
    float s, c;

    // The norm of the gyro*dt
    float norm = 0;

    // Identity matrix
    float I[3][3];

    // The cross product matrix squared
    float Wsq[3][3];

    // Exponential matrix
    float Rexp[3][3];

    // Temporary value for DCM when multiplying
    float Rminus[3][3];

    // Local variable for w*dt
    float wt[3];

    // Scale w by dt
    // Add squares of w for calculating the norm
    // Initialize identity matrix
    // Initialize Rminus
    for (i = 0; i < 3; i++) {
        for (j = 0; j < 3; j++) {
            I[i][j] = 0;
            Rminus[i][j] = DCM[i][j];
            DCM[i][j] = 0;
        }
        wt[i] = (float) w[i] / gyro_scale;
        wt[i] = w[i] * dt;
        norm += wt[i] * wt[i];
        I[i][i] = 1;
    }
    norm = sqrt(norm) / 2;

    // Cross product matrix of gyro*dt
    float W[3][3] = {
        {0, -wt[2], wt[1]},
        {wt[2], 0, -wt[0]},
        {-wt[1], wt[0], 0}
    };

    // Cross product matrix squared
    // Matrix multiplication
    for (i = 0; i < 3; i++) {
        for (j = 0; j < 3; j++) {
            Wsq[i][j] = 0;
            for (k = 0; k < 3; k++) {
                Wsq[i][j] += W[i][k] * W[k][j];
            }
        }
    }


    // Calculate the sinc function
    if (norm > 3) {
        s = sin(norm) / norm;
    } else {
        s = 1 - powf(norm, 2) / 6 + powf(norm, 4) / 120 - powf(norm, 6) / 5040;
    }
    c = cos(norm);

    for (i = 0; i < 3; i++) {
        for (j = 0; j < 3; j++) {
            Rexp[i][j] = I[i][j] + (s * c * W[i][j]) + (s * s * Wsq[i][j] * 0.5);
        }
    }

    // Matrix multiplication
    for (i = 0; i < 3; i++) {
        for (j = 0; j < 3; j++) {
            for (k = 0; k < 3; k++) {
                DCM[i][j] += Rminus[i][k] * Rexp[k][j];
            }
        }
    }
}

void RotMat_Closedloop(float DCM[3][3], float Bias[3], int w[3], float Accel[3], float Mag[3]) {
    // Variables for for loops
    int i, j, k;

    // Sinc(norm/2) and cos(norm/2)
    float s, c;

    // The norm of the gyro*dt
    float norm = 0;

    // Identity matrix
    float I[3][3];

    // The cross product matrix squared
    float Wsq[3][3];

    // Exponential matrix
    float Rexp[3][3];

    // Temporary value for DCM when multiplying
    float Rminus[3][3];

    // Accel and Mag rotated into body coordinates
    float wmeas_a[3], wmeas_m[3];
    float anorm = 0, mnorm = 0;

    // Temporary variables for calculating wmeas_a and wmeas_m
    float tempa[3], tempm[3];

    // Inertial frame accel and mag
    float accelinit[3] = {0, 0, 1}, maginit[3] = {0.4772, 0.1127, 0.8716};

    // Mag misalignment
    float misag[3][3] = {
        {0.9763, -0.1644, 0.1406},
        {0.2126, 0.8483, -0.4849},
        {-0.0396, 0.5033, 0.8632}
    };
    float alignMag[3];

    // Weights of feedback
    float kp_a = 10, kp_m = 1, ki_a = 0.5, ki_m = 0.1;

    // Used to correct bias
    float bdot[3];

    // Local variable for w*dt
    float wt[3];

    /*************** Initialize Variables **************/
    // Scale w by dt
    // Initialize I, Rminus, DCM, wmeas_a, wmeas_m to zero
    // Calculate the norm of w
    for (i = 0; i < 3; i++) {
        for (j = 0; j < 3; j++) {
            I[i][j] = 0;
            Rminus[i][j] = DCM[i][j];
            DCM[i][j] = 0;
        }
        alignMag[i] = 0;
        wt[i] = ((float) w[i]) / gyro_scale;
        bdot[i] = 0;
        wmeas_a[i] = 0;
        wmeas_m[i] = 0;
        tempa[i] = 0;
        tempm[i] = 0;
        anorm += Accel[i] * Accel[i];
        mnorm += Mag[i] * Mag[i];
        I[i][i] = 1;
    }
    anorm = sqrt(anorm);
    mnorm = sqrt(mnorm);

    for (i = 0; i < 3; i++) {
        Accel[i] = Accel[i] / anorm;
        Mag[i] = Mag[i] / mnorm;
    }

    for (i = 0; i < 3; i++) {
        for (j = 0; j < 3; j++) {
            alignMag[i] += misag[i][j] * Mag[j];
        }
    }
    for (i = 0; i < 3; i++) {
        /***************** Misalignment Correction *****************/
        //Mag[i] = alignMag[i];
    }

    /*************** Feedback Calculations *******************/

    // Cross product matrices for accel and mag
    float accelx[3][3] = {
        {0, -Accel[2], Accel[1]},
        {Accel[2], 0, -Accel[0]},
        {-Accel[1], Accel[0], 0}
    };
    float magx[3][3] = {
        {0, -Mag[2], Mag[1]},
        {Mag[2], 0, -Mag[0]},
        {-Mag[1], Mag[0], 0}
    };

    // Calculate wmeas_a and wmeas_b
    for (i = 0; i < 3; i++) {
        for (j = 0; j < 3; j++) {
            tempa[i] += Rminus[i][j] * accelinit[j];
            tempm[i] += Rminus[i][j] * maginit[j];
        }
    }
    for (i = 0; i < 3; i++) {
        for (j = 0; j < 3; j++) {
            wmeas_a[i] += accelx[i][j] * tempa[j];
            wmeas_m[i] += magx[i][j] * tempm[j];
        }
    }

    // Update w and calculate bdot
    for (i = 0; i < 3; i++) {
        wt[i] = wt[i] + kp_a * wmeas_a[i] + kp_m * wmeas_m[i];
        bdot[i] = -ki_a * wmeas_a[i] - ki_m * wmeas_m[i];
        Bias[i] += bdot[i] * dt;
    }

    /*************** Closed Loop Done - Now do Estimation *************/

    for (i = 0; i < 3; i++) {
        wt[i] = wt[i] * dt;
        norm += wt[i] * wt[i];
    }
    norm = sqrt(norm) * 0.5;

    // Cross product matrix of gyro*dt
    float W[3][3] = {
        {0, -wt[2], wt[1]},
        {wt[2], 0, -wt[0]},
        {-wt[1], wt[0], 0}
    };

    // Cross product matrix squared
    // Matrix multiplication
    for (i = 0; i < 3; i++) {
        for (j = 0; j < 3; j++) {
            Wsq[i][j] = 0;
            for (k = 0; k < 3; k++) {
                Wsq[i][j] += W[i][k] * W[k][j];
            }
        }
    }

    // Calculate the sinc function
    if (norm > 3) {
        s = sin(norm) / norm;
    } else {
        s = 1 - powf(norm, 2) / 6 + powf(norm, 4) / 120 - powf(norm, 6) / 5040;
    }
    c = cos(norm);

    for (i = 0; i < 3; i++) {
        for (j = 0; j < 3; j++) {
            Rexp[i][j] = I[i][j] + (s * c * W[i][j]) + (s * s * Wsq[i][j] * 0.5);
        }
    }

    // Matrix multiplication
    for (i = 0; i < 3; i++) {
        for (j = 0; j < 3; j++) {
            for (k = 0; k < 3; k++) {
                DCM[i][j] += Rminus[i][k] * Rexp[k][j];
            }
        }
    }
}