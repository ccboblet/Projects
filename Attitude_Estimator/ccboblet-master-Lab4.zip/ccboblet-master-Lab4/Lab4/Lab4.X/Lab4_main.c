/* 
 * File:   Lab4_main.c
 * Author: Burned Yams
 *
 * Created on March 10, 2020, 5:30 PM
 */

#include <BOARD.h>
#include <serial.h>
#include <I2C.h>
#include <MPU9250.h>
#include <stdio.h>
#include <stdlib.h>
#include <RotationMatrix.h>
#include <Oled.h>
#include <math.h>

/*
 * 
 */
int main(int argc, char** argv) {
    // Initialize functions
    BOARD_Init();
    SERIAL_Init();
    TIMERS_Init();
    MPU9250_Init();
    OledInit();

    // String for printing to the Oled
    char str[50];

    // These variables hold time
    int time = 0;

    // Variables for for loops
    int i, j, k, t;

    // Gyro Accel and Mag readings
    int gyro[3];
    float accel[3], mag[3], maginit[3];
    float gyrobias[3];

    // Declare the DCM and angle matrix and initialize them to zero
    float DCM[3][3];

    // The angles are (y)aw (p)itch and (r)oll
    int angles[3];

    // Initialize angles and DCM
    for (i = 0; i < 3; i++) {
        angles[i] = 0;
        gyrobias[i] = 0;
        for (j = 0; j < 3; j++) {
            DCM[i][j] = 0;
        }
        DCM[i][i] = 1;
    }

    /*************** Wait to get gyro biases *****************/

    // Get current time
    time = TIMERS_GetMilliSeconds();

    // Wait a second to warmup
    while ((TIMERS_GetMilliSeconds() - time) < 1000) {
    }
    time = TIMERS_GetMilliSeconds();
    // Get initial values
    gyro[0] = MPU9250_ReadGyroX();
    gyro[1] = MPU9250_ReadGyroY();
    gyro[2] = MPU9250_ReadGyroZ();
    // Take 512 data points at 50 Hz to calculate the bias
    for (i = 0; i < 512; i++) {
        // Wait for 20ms for 50Hz sampling
        while ((TIMERS_GetMilliSeconds() - time) < 20) {
        }
        // Calculate difference from initial
        gyrobias[0] += (float) (MPU9250_ReadGyroX() - gyro[0]);
        gyrobias[1] += (float) (MPU9250_ReadGyroY() - gyro[1]);
        gyrobias[2] += (float) (MPU9250_ReadGyroZ() - gyro[2]);

        OledClear(OLED_COLOR_BLACK);
        sprintf(str, "%4.0f %4.0f %4.0f\nCalculating Bias", gyrobias[0], gyrobias[1], gyrobias[2]);
        OledDrawString(str);
        OledUpdate();

        // Update time
        time = TIMERS_GetMilliSeconds();
    }
    // Divide by number of samples to get bias
    gyrobias[0] = (gyrobias[0] / 512) + (float) gyro[0];
    gyrobias[1] = (gyrobias[1] / 512) + (float) gyro[1];
    gyrobias[2] = (gyrobias[2] / 512) + (float) gyro[2];

    /***************** Main Loop **********************/
    while (1) {
        /* Read from each axis and print values. The sampling frequency can be 
         * changed by manipulating the value in the if statements. The sensor
         * can be changed by changing the functions used in the if statement.
         */
        if ((TIMERS_GetMilliSeconds() - time) > 20) {
            t += 1;
            if (t > 5) {
                // Print the angles every 100ms
                OledClear(OLED_COLOR_BLACK);
                sprintf(str, "%d %d %d", angles[0], angles[1], angles[2]);
                OledDrawString(str);
                OledUpdate();
                t = 0;
            }


            // Read Gyro
            gyro[0] = (MPU9250_ReadGyroX() - (int) gyrobias[0]);
            gyro[1] = (MPU9250_ReadGyroY() - (int) gyrobias[1]);
            gyro[2] = (MPU9250_ReadGyroZ() - (int) gyrobias[2]);

            // Read accel
            accel[0] = (float) (MPU9250_ReadAccelX()) / 16400;
            accel[1] = (float) (MPU9250_ReadAccelY()) / 16400;
            accel[2] = (float) (MPU9250_ReadAccelZ()) / 16400;

            // Read mag
            maginit[0] = ((float) (MPU9250_ReadMagX()));
            maginit[1] = ((float) (MPU9250_ReadMagY()));
            maginit[2] = ((float) (MPU9250_ReadMagZ()));
            float Atilde[3][3] = {
                {0.005980, 0.00004729, 0.0003916},
                {-0.0002969, 0.004926, 0.0001102},
                {0.000804604, 0.0001263, 0.003688}
            };
            float Btilde[3] = {0.2516, -0.6554, 0.7675};
            for (i = 0; i < 3; i++) {
                mag[i] = 0;
                for (j = 0; j < 3; j++) {
                    mag[i] += Atilde[i][j] * maginit[j];
                }
                mag[i] += Btilde[i];
            }

#define TRIAD
#ifdef TRIAD
            /****************** TRIAD ************************/

            // Normalize acc and mag
            float accels[3], mags[3];
            float anorm, mnorm;
            anorm = 0;
            mnorm = 0;
            for (i = 0; i < 3; i++) {
                anorm += accel[i] * accel[i];
                mnorm += mag[i] * mag[i];
            }
            anorm = sqrt(anorm);
            mnorm = sqrt(mnorm);
            for (i = 0; i < 3; i++) {
                accels[i] = accel[i] / anorm;
                mags[i] = mag[i] / mnorm;
            }

            // Declare cross product matrices
            float accelInertial[3] = {0, 0, 1}, magInertial[3] = {0.4772, 0.1127, 0.8716};
            float magsx[3][3] = {
                {0, -mags[2], mags[1]},
                {mags[2], 0, -mags[0]},
                {-mags[1], mags[0], 0}
            };
            float accelsx[3][3] = {
                {0, -accels[2], accels[1]},
                {accels[2], 0, -accels[0]},
                {-accels[1], accels[0], 0}
            };
            float mInitx[3][3] = {
                {0, -magInertial[2], magInertial[1]},
                {magInertial[2], 0, -magInertial[0]},
                {-magInertial[1], magInertial[0], 0}
            };
            float aInitx[3][3] = {
                {0, -accelInertial[2], accelInertial[1]},
                {accelInertial[2], 0, -accelInertial[0]},
                {-accelInertial[1], accelInertial[0], 0}
            };

            // Calculate and normalize m and M
            float m[3];
            float M[3];
            for (i = 0; i < 3; i++) {
                m[i] = 0;
                M[i] = 0;
            }
            for (i = 0; i < 3; i++) {
                for (j = 0; j < 3; j++) {
                    m[i] += magsx[i][j] * accels[j];
                    M[i] += mInitx[i][j] * accelInertial[j];
                }
            }
            anorm = 0;
            mnorm = 0;
            for (i = 0; i < 3; i++) {
                anorm += m[i] * m[i];
                mnorm += M[i] * M[i];
            }
            anorm = sqrt(anorm);
            mnorm = sqrt(mnorm);
            for (i = 0; i < 3; i++) {
                m[i] = m[i] / anorm;
                M[i] = M[i] / mnorm;
            }

            // Calculate components of A
            float Mx[3] = {0, 0, 0};
            float mx[3] = {0, 0, 0};
            for (i = 0; i < 3; i++) {
                mx[i] = 0;
                Mx[i] = 0;
            }
            for (i = 0; i < 3; i++) {
                for (j = 0; j < 3; j++) {
                    mx[i] += magsx[i][j] * m[j];
                    Mx[i] += mInitx[i][j] * M[j];
                }
            }
            float Aleft[3][3] = {
                {magInertial[0], M[0], Mx[0]},
                {magInertial[1], M[1], Mx[1]},
                {magInertial[2], M[2], Mx[2]}
            };
            float Aright[3][3] = {
                {mags[0], mags[1], mags[2]},
                {m[0], m[1], m[2]},
                {mx[0], mx[1], mx[2]}
            };

            // Clear A and calculate A
            float A[3][3];
            for (i = 0; i < 3; i++) {
                for (j = 0; j < 3; j++) {
                    A[i][j] = 0;
                }
            }
            // Matrix multiplication
            for (i = 0; i < 3; i++) {
                for (j = 0; j < 3; j++) {
                    for (k = 0; k < 3; k++) {
                        A[i][j] += Aleft[i][k] * Aright[k][j];
                    }
                }
            }

            // Transpose A
            for (i = 0; i < 3; i++) {
                for (j = 0; j < 3; j++) {
                    DCM[i][j] = A[j][i];
                }
            }
            /**************** End TRIAD **************************/
#endif

#ifndef TRIAD
            // Three types of estimation
            //RotMat_SimpleForward(DCM, gyro);
            //RotMat_Openloop(DCM, gyro);
            RotMat_Closedloop(DCM, gyrobias, gyro, accel, mag);
#endif
            RotMat_GetDegree(DCM, angles);
            time = TIMERS_GetMilliSeconds();
        }
    }

    return (EXIT_SUCCESS);
}