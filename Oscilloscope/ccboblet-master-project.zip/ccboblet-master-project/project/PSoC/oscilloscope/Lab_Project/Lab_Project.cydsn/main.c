/*******************************************************************************
* This program samples analog voltages from 2 channels and sends that data over 
* USB to the RPi. The sampling rate is determined by the RPi and communicated 
* over I2C. A mux is used to cycle between 2 potentiometer values. Those 
* values are sent to the RPi using I2C.
*******************************************************************************
* Author: Colin Boblet
* Section: Wednesday
*******************************************************************************/
#include <project.h>

// USB device number
#define USBFS_DEVICE 0u

// IN endpoint descriptor number
#define IN_EP_NUM_1 1u

// OUT endpoint descriptor number
#define IN_EP_NUM_2 2u

// Length of packet to the host
#define IN_LEN 64

// Size of ping pong array
#define ARRAY_LEN 128

// Define I2C buffer sizes
#define RD_BUFFER_SIZE 2u
#define WR_BUFFER_SIZE 1u

// Arrays for DMA and USB transfers
uint8 adc_data1[ARRAY_LEN], adc_data2[ARRAY_LEN];


// Define arrays for I2C
uint8 read_buffer[RD_BUFFER_SIZE] = {0};
uint8 write_buffer[WR_BUFFER_SIZE] = {0};

/* Defines for DMA_1 */
#define DMA_1_BYTES_PER_BURST 1
#define DMA_1_REQUEST_PER_BURST 1
#define DMA_1_SRC_BASE (CYDEV_PERIPH_BASE)
#define DMA_1_DST_BASE (CYDEV_SRAM_BASE)

    /* Defines for DMA_2 */
#define DMA_2_BYTES_PER_BURST 1
#define DMA_2_REQUEST_PER_BURST 1
#define DMA_2_SRC_BASE (CYDEV_PERIPH_BASE)
#define DMA_2_DST_BASE (CYDEV_SRAM_BASE)

/* Variable declarations for DMA_2 */
uint8 DMA_2_Chan;
uint8 DMA_2_TD[2];

/* Variable declarations for DMA_1 */
uint8 DMA_1_Chan;
uint8 DMA_1_TD[2];

// Start position in array for USB transfers
uint8 adc_start1 = 64, adc_start2 = 64;

// Flag to signal when new data is ready
uint8 adc_flag1 = 0, adc_flag2 = 0;

// Set flag to signal that new data is ready and move start position of USB IN transfer
CY_ISR(adc1){
    
    // Set flag high
    adc_flag1 = 1;
    
    // Set IN transfer start position
    if(adc_start1 == 64){
        adc_start1 = 0;
    } else{
        adc_start1 = 64;
    }
}

CY_ISR(adc2){
    
    // Set flag high
    adc_flag2 = 1;
    
    // Set IN transfer start position
    if(adc_start2 == 64){
        adc_start2 = 0;
    } else{
        adc_start2 = 64;
    }
}

int main()
{
    CyGlobalIntEnable;
    
    /* Hardware Start */
    AMux_1_Start();
    ADC_DelSig_1_Start();
    ADC_SAR_1_Start();
    ADC_SAR_1_StartConvert();
    ADC_SAR_2_Start();
    ADC_SAR_2_StartConvert();
    isr_1_StartEx(adc1);
    isr_2_StartEx(adc2);
    
    // Variable for tracking how many bytes have been read by the master
    uint8 readbyteCount = 0u;
    
    // Command register to capture writes from I2C
    uint8 command_reg = 0;
    
    // Variable to hold the sample rate to write to the clock controlling the DMA
    uint16 samplerate = 10;
    Clock_1_SetDividerValue((100/samplerate));
    
    // Flag for if the start command has been given
    uint8 start = 0;
    
    // Varaibles to hold the output from the potentiometers
    uint32 adcval1, adcval2;
    
    // Set up slave write data buffer
    I2CS_SlaveInitWriteBuf((uint8 *) write_buffer, WR_BUFFER_SIZE); 
    
    // Set up slave read data buffer
    I2CS_SlaveInitReadBuf((uint8 *) read_buffer, RD_BUFFER_SIZE);
    
    // Start I2C slave component
    I2CS_Start();
    
    
    // Set up USBFS settings
    USBFS_1_Start(USBFS_DEVICE, USBFS_1_5V_OPERATION);
    while (!USBFS_1_GetConfiguration()){};

    /* DMA Configuration for DMA_1 */
    DMA_1_Chan = DMA_1_DmaInitialize(DMA_1_BYTES_PER_BURST, DMA_1_REQUEST_PER_BURST, 
        HI16(DMA_1_SRC_BASE), HI16(DMA_1_DST_BASE));
    DMA_1_TD[0] = CyDmaTdAllocate();
    DMA_1_TD[1] = CyDmaTdAllocate();
    CyDmaTdSetConfiguration(DMA_1_TD[0], 64, DMA_1_TD[1], DMA_1__TD_TERMOUT_EN | CY_DMA_TD_INC_DST_ADR);
    CyDmaTdSetConfiguration(DMA_1_TD[1], 64, DMA_1_TD[0], DMA_1__TD_TERMOUT_EN | CY_DMA_TD_INC_DST_ADR);
    CyDmaTdSetAddress(DMA_1_TD[0], LO16((uint32)ADC_SAR_1_SAR_WRK0_PTR), LO16((uint32)adc_data1));
    CyDmaTdSetAddress(DMA_1_TD[1], LO16((uint32)ADC_SAR_1_SAR_WRK0_PTR), LO16((uint32)adc_data1+64));
    CyDmaChSetInitialTd(DMA_1_Chan, DMA_1_TD[0]);

    /* DMA Configuration for DMA_2 */
    DMA_2_Chan = DMA_2_DmaInitialize(DMA_2_BYTES_PER_BURST, DMA_2_REQUEST_PER_BURST, 
        HI16(DMA_2_SRC_BASE), HI16(DMA_2_DST_BASE));
    DMA_2_TD[0] = CyDmaTdAllocate();
    DMA_2_TD[1] = CyDmaTdAllocate();
    CyDmaTdSetConfiguration(DMA_2_TD[0], 64, DMA_2_TD[1], DMA_2__TD_TERMOUT_EN | CY_DMA_TD_INC_DST_ADR);
    CyDmaTdSetConfiguration(DMA_2_TD[1], 64, DMA_2_TD[0], DMA_2__TD_TERMOUT_EN | CY_DMA_TD_INC_DST_ADR);
    CyDmaTdSetAddress(DMA_2_TD[0], LO16((uint32)ADC_SAR_2_SAR_WRK0_PTR), LO16((uint32)adc_data2));
    CyDmaTdSetAddress(DMA_2_TD[1], LO16((uint32)ADC_SAR_2_SAR_WRK0_PTR), LO16((uint32)adc_data2+64));
    CyDmaChSetInitialTd(DMA_2_Chan, DMA_2_TD[0]);

    CyDmaChEnable(DMA_2_Chan, 1);
    CyDmaChEnable(DMA_1_Chan, 1);

    for(;;){
        
        // Check if configuration is changed
        if (0u != USBFS_1_IsConfigurationChanged()){
            
            // Re-enable endpoint when device is configured
            if (0u != USBFS_1_GetConfiguration()){
            }
        }

        if((USBFS_1_GetEPState(IN_EP_NUM_1) == USBFS_1_IN_BUFFER_EMPTY) && (start == 1)){
            if(adc_flag1 == 1){
            
                // Transfer data to the host
                USBFS_1_LoadInEP(IN_EP_NUM_1, adc_data1+adc_start1, IN_LEN);
                adc_flag1 = 0;
            }
        }
        
        if((USBFS_1_GetEPState(IN_EP_NUM_2) == USBFS_1_IN_BUFFER_EMPTY) && (start == 1)){
            if(adc_flag2 == 1){
            
                // Transfer data to the host
                USBFS_1_LoadInEP(IN_EP_NUM_2, adc_data2+adc_start2, IN_LEN);
                adc_flag1 = 0;
            }
        }
        
        
        // Check if the command register has been written
        if(I2CS_SlaveStatus() & I2CS_SSTAT_WR_CMPLT){
            
            // Copy command into command register
            command_reg = write_buffer[0];
            
            // Check for the samplerate signal
            if((command_reg&0x80) && (command_reg!=0xff)){
                samplerate = command_reg&0x7f;
                Clock_1_SetDividerValue((100/samplerate));
            }
            
            // Check for the start command
            if(command_reg == 0xff){
                start = 1;
            }
            
            // Clear status
            I2CS_SlaveClearWriteStatus();
            I2CS_SlaveClearWriteBuf();
        }
        
    
        // Check if the slave buffer has been read
        if(I2CS_SlaveStatus() & I2CS_SSTAT_RD_CMPLT){
            
            // Read how many bytes have been read by the master
            readbyteCount = I2CS_SlaveGetReadBufSize();
            
            // Check if the read buffer is now empty
            if((readbyteCount == RD_BUFFER_SIZE) && (start == 1)){
                
                // Clear read status
                I2CS_SlaveClearReadStatus();
                I2CS_SlaveClearReadBuf();
                
                // Mux between analog inputs and read potentiometers
                AMux_1_Select(0);
                adcval1 = ADC_DelSig_1_Read32();
                AMux_1_Select(1);
                adcval2 = ADC_DelSig_1_Read32();

                // Correct for edge cases
                if(adcval1 > 255){
                    adcval1 = 0;
                }
                if(adcval2 > 255){
                    adcval2 = 0;
                }
                
                /* 
                * Disable the interrupts when writing to the Read buffer
                * so that the Master cannot read the slave buffer during the act of writing
                * to the buffer.
                */
                
                CyGlobalIntDisable;

                // Write to the buffer
                // Keep this code minimized so only a short time is spent without interrupts.
                read_buffer[0] = adcval1;
                read_buffer[1] = adcval2;



                // Turn the interrupts back on
                CyGlobalIntEnable;
            }
        }
    }
}