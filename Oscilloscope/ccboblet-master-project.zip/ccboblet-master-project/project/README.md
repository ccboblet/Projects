# CMPE 121 Final Project Repository

# Directories

raspi:  All Raspberry Pi files related to final project

PSoC: All PSoC files related to final project

docs: Documentation on final project


