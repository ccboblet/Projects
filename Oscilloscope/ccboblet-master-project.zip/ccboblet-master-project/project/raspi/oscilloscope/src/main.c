/*****************************************************************************
* This program cooperates with a PSoC 5 to create an oscilloscope. The PSoC 
* uses ADC converters to convert analog signals to digital and sends that data 
* to the RPi over a USB connection. The command line checking and trigger 
* function are in main, while the drawing function and I2C functions are in 
* seperate files. Inspiration has been taken from examples on the CSE 121 canvas.
******************************************************************************
* Author: Colin Boblet
* Section: Wednesday
*****************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include <shapes.h>
#include <fontinfo.h>
#include <math.h>
#include <wiringPiI2C.h>
#include <termios.h>
#include <errno.h>
#include <libusb.h>
#include "i2c.h"
#include "i2c.c"
#include "draw.h"
#include "draw.c"

int main(int argc, char **argv) {
    
  // Variables used to store screen height and width
  int width, height;
  
  // Set data line colors and transparency
  int color1[4] = {0,255,0,1}, color2[4] = {255,0,0,1};
  
  // Declare arrays for data
  int data1[1000001], data2[1000001];
  
  // Save current screen, initialize height and width, and start drawing
  saveterm();
  init(&width, &height);
  
  // Variable to hold pot values
  int pots[2];
  
  // Oscilloscope settings initialized to default settings
  
  // Default mode is triggered
  int mode = 1;
  
  // Default trigger level is 2.5V
  int level = 2500;
  
  // Default trigger slope is positive
  int slope = 1;
  
  // Default trigger channel is channel 1
  int channel = 1;
  
  // Default x scale is 1ms per division
  int xscale = 1000;
  
  // Default y scale is 1V per division
  int  yscale = 1000;
  
  // Default sample rate is 10 ksamples per second
  int samplerate = 10;
  
  // The offset for moving the waves up and down is 0
  int offset1 = 0, offset2 = 0;
  
  // Used as a flag for detecting invalid command line inputs
  int error = 0;
  
  // USB device ID
  libusb_device_handle* dev;
  
  // Variable to hold number of bytes recieved
  int rcvd_bytes, return_val;
  
  // Array to hold data recieved from USB
  char ch1_data[64];
  char ch2_data[64];
  
  // Check for invalid command line inputs and record valid inputs
  for(int i = 0; i<argc; i++){
    
    // Check for mode
    if(!strcmp("-m", argv[i])){
      if(argv[i+1] == NULL){
        printf("No value entered after %s \n", argv[i]);
        return 1;
      }
      if(!strcmp(argv[i+1], "free")){
        mode = 0;
      } else{
        if(!strcmp(argv[i+1], "trigger")){
          mode = 1;
        } else{
          printf("Invalid mode \n");
          return 1;
        }
      }
    }
    
    // Check for trigger level
    if(!strcmp("-t", argv[i])){
      if(argv[i+1] == NULL){
        printf("No value entered after %s \n", argv[i]);
        return 1;
      }
      level = atoi(argv[i+1]);
      for(int i = 0; i <= 50; i++){
        if(level == 100*i){
          error = 1;
        }
      }
      if(error == 0){
        printf("Invalid trigger level \n");
        return 1;
      } else{
        error = 0;
      }
    }
    
    // Check for trigger slope
    if(!strcmp("-s", argv[i])){
      if(argv[i+1] == NULL){
        printf("No value entered after %s \n", argv[i]);
        return 1;
      }
      if(!strcmp(argv[i+1], "pos")){
        slope = 1;
      } else{
        if(!strcmp(argv[i+1], "neg")){
          slope = 0;
        } else{
          printf("Invalid slope \n");
          return 1;
        }
      }
    }
    
    // Check for sample rate
    if(!strcmp("-r", argv[i])){
      if(argv[i+1] == NULL){
        printf("No value entered after %s \n", argv[i]);
        return 1;
      }
      samplerate = atoi(argv[i+1]);
      if(samplerate == 1 || samplerate == 10 || samplerate == 20 || samplerate == 50 || samplerate == 100){
      } else{
        printf("Invalid sample rate \n");
        return 1;
      }
    }
    
    // Check for trigger channel
    if(!strcmp("-c", argv[i])){
      if(argv[i+1] == NULL){
        printf("No value entered after %s \n", argv[i]);
        return 1;
      }
      channel = atoi(argv[i+1]);
      if(channel == 1 || channel == 2){
      } else{
        printf("Invalid trigger channel \n");
        return 1;
      }
    }
    
    // Chekc for x scale
    if(!strcmp("-x", argv[i])){
      if(argv[i+1] == NULL){
        printf("No value entered after %s \n", argv[i]);
        return 1;
      }
      xscale = atoi(argv[i+1]);
      if(xscale == 100 || xscale == 500 || xscale == 1000 || xscale == 2000 || xscale == 5000 || xscale == 10000 || xscale == 50000 || xscale == 100000){
      } else{
        printf("Invalid x scale \n");
        return 1;
      }
    }
    
    // Check for y scale
    if(!strcmp("-y", argv[i])){
      if(argv[i+1] == NULL){
        printf("No value entered after %s \n", argv[i]);
        return 1;
      }
      yscale = atoi(argv[i+1]);
      if(yscale == 100 || yscale == 500 || yscale == 1000 || yscale == 2000 || yscale == 2500){
      } else{
        printf("Invalid y scale \n");
        return 1;
      }
    }
  }
  
  // Set necessary number of data points and scale trigger level
  int datacount = ((xscale/100)*samplerate) + 1;
  level = level/20;
  writesamplerate(samplerate);
  
  
  // Set up USB
  libusb_init(NULL);
  
  // Open USB device
  dev = libusb_open_device_with_vid_pid(NULL, 0x04B4, 0x8051);
  
  // Exit program if no device found
  if(dev == NULL){
    perror("Device not found \n");
    return 1;
  }
  
  // Reset USB device
  if(libusb_reset_device(dev) != 0){
    perror("Device reset failed \n");
    return 1;
  }
  
  // Set USB configuration
  if(libusb_set_configuration(dev, 1) !=0){
    perror("Set configuration failed \n");
    return 1;
  }
  
  // Claim USB interface
  if(libusb_claim_interface(dev, 0) != 0){
    perror("Cannot claim interface \n");
    return 1;
  }
  
  
  /*
   * The following varaibles and forever loop constitute data 
   * collection and and trigger detection. After data has been collected 
   * and trigger detection has been handled, the data is printed to the 
   * screen.
   */
   
  // These variables are used to count how much of each wave has been recorded
  int count1 = 0, count2 = 0;
  
  // This is a flag that tells the program it is the first time through and data should be thrown away
  int first = 1;
  
  // These variables are used to track the last value and flag if a trigger has been detected
  int last, triggered;
  
  // Send the signal to the PSoC to start transmitting data
  starti2c();
  
  for(;;){
      
    // Recieve data from the PSoC over USB for channel 1
    return_val = libusb_bulk_transfer(dev, (0x01 | 0x80), ch1_data, 64, &rcvd_bytes, 0);
    
    // If channel 1 is the trigger channel initialize the trigger comparison
    if(channel == 1){
      last = ch1_data[0];
    }
    
    /*
    * This channel has the potential to record data is the datacount limit has 
    * not been reached and there are bytes left from the most recent USB 
    * transmition.
    */
    for(int i = 0; (i < rcvd_bytes) && (count1 < datacount); i++){
        
      // Record a trigger if all conditions are met
      if(channel == 1){
          if(slope == 1){
              
              // These are the conditions for positive slope
              if((ch1_data[i] > level) && (level >= last)){
                  triggered = 1;
              }
          }
          
          // These are conditions for negative slope
          if(slope == 0){
              if((ch1_data[i] < level) && (level <= last)){
                  triggered = 1;
              }
          }
      }
      
      // If mode is free or a trigger has occured start collecting data
      if(mode == 0 || triggered == 1){
        data1[count1] = ch1_data[i];
        count1++;
      }
      
      // If no trigger occured, update
      if(channel == 1){
          last = ch1_data[i];
      }
    }
    
    return_val = libusb_bulk_transfer(dev, (0x02 | 0x80), ch2_data, 64, &rcvd_bytes, 0);
    
    if(channel == 2){
      last = ch2_data[0];
    }
    
    
    /*
    * This channel has the potential to record data is the datacount limit has 
    * not been reached and there are bytes left from the most recent USB 
    * transmition.
    */
    for(int i = 0; (i < rcvd_bytes) && (count2 < datacount); i++){
        
      // Record a trigger if all conditions are met
      if(channel == 2){
          if(slope == 1){
              
              // These are the conditions for positive slope
              if((ch2_data[i] > level) && (level >= last)){
                  triggered = 1;
              }
          }
          
          // These are conditions for negative slope
          if(slope == 0){
              if((ch2_data[i] < level) && (level <= last)){
                  triggered = 1;
              }
          }
      }
      
      // If mode is free or a trigger has occured start collecting data
      if(mode == 0 || triggered == 1){
        data2[count2] = ch2_data[i];
        count2++;
      }
      
      // If no trigger occured, update
      if(channel == 2){
        last = ch2_data[i];
      }
    }
    
    // If it is the first time through throw away buffered data
    if(first){
      count1 = 0;
      count2 = 0;
      triggered = 0;
      first = 0;
    }
    
    // If sufficient data has been gathered for both channels now draw
    if(count1>=datacount && count2 >=datacount){
        
      // Read the potentiometers for offset values
      readpots(pots);
        
      // Start drawing
      Start(width, height);

      // Draw a background and division lines
      drawlines(width, height);
      
      printScaleSettings(xscale, yscale, triggered, channel, level, mode, slope);
      
      // Draw data
      drawdata(width, height, xscale, yscale, samplerate, data1, color1, pots[0], datacount);
      drawdata(width, height, xscale, yscale, samplerate, data2, color2, pots[1], datacount);
      
      // Finish Drawing
      End();
      
      // Reset the counts and trigger
      count1 = 0;
      count2 = 0;
      first = 1;
      triggered = 0;
      
      // Pause briefly between cycles
      sleep(0.5);
    }
  }
  
  // The program will never get here these are just here for best practice
  restoreterm();
  finish();
  return 0;
}
