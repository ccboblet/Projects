/*****************************************************************************
* This program cooperates with a PSoC 5 to create an oscilloscope. The PSoC 
* uses ADC converters to convert analog signals to digital and sends that data 
* to the RPi over a USB connection
******************************************************************************
* Author: Colin Boblet
* Section: Wednesday
*****************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include <shapes.h>
#include <fontinfo.h>
#include <math.h>
#include <wiringPiI2C.h>

/* 
 * This function draws the background of the oscilloscope. 
 * It takes in the width and height of the screen. There are 
 * 5 y divisions and 10 x divisions.
 */
void drawlines(int width, int height);

/* 
 * This function draws data on the screen. This function takes in the 
 * screen width height, x scale in ms, y scale in mV, sample rate in 
 * ksamples per second, data array, line color, vertical offset, and 
 * number of data points needed
 */
void drawdata(int width, int height, int xscale, int yscale, int samplerate, int data[1000001], int color[4], int offset, int datacount);

/*
 * This function prints the settings to the screen
 */ 
void printScaleSettings(int xscale, int yscale, int trigger, int channel, int level, int mode, int slope);
