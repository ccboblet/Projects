/*****************************************************************************
* This program defines functions for i2c communication between the RPi 
* and the PSoC.
******************************************************************************
* Author: Colin Boblet
* Section: Wednesday
*****************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include <errno.h>
#include <wiringPiI2C.h>

// This function tells the PSoC to start
int starti2c();

// This function writes the samplerate to the PSoC
int writesamplerate(int samplerate);

// This function reads from the pots
int readpots(int pots[2]);
