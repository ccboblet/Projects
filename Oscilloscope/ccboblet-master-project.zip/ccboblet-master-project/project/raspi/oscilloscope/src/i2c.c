/*****************************************************************************
* This program defines functions for i2c communication between the RPi 
* and the PSoC. Inspiration has been taken from examples on the CSE 121 canvas.
******************************************************************************
* Author: Colin Boblet
* Section: Wednesday
*****************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include <errno.h>
#include <wiringPiI2C.h>
#include "i2c.h"

#define I2C_SLAVE_ADDR 0x53

// Write the start signal returns 1 for error
int starti2c(){
	int fd;
	unsigned int command = 0xff;

	// Initialize the I2C interface.
	// It returns a standard file descriptor.
	fd = wiringPiI2CSetup(I2C_SLAVE_ADDR);
	if (fd == -1){
		return 1;
	}

	// Write command to PSoC
	wiringPiI2CWrite(fd, command);
	close(fd);
	return 0;
	}

// Write the sample rate returns 1 for error
int writesamplerate(int samplerate){
	int fd;
	unsigned int command = 0x80 | samplerate;

	// Initialize the I2C interface.
	// It returns a standard file descriptor.
	fd = wiringPiI2CSetup(I2C_SLAVE_ADDR);
	if (fd == -1){
		return 1;
	}

	// Write command to PSoC
	wiringPiI2CWrite(fd, command);
	close(fd);
	return 0;
	}
   
// Read pot values returns 1 for an error
int readpots(int pots[2]){
	int fd;

	// Initialize the I2C interface.
	// It returns a standard file descriptor.
	fd = wiringPiI2CSetup(I2C_SLAVE_ADDR);
	if (fd == -1){
		return 1;
	}

	// Read potentiometer data
	pots[0] = wiringPiI2CRead(fd);
	pots[1] = wiringPiI2CRead(fd);
	close(fd);
	return 0;
	}
