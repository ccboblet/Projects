/*****************************************************************************
* This file defines functions for the display of an oscilloscope. 
* Inspiration has been taken from examples on the CSE 121 canvas.
******************************************************************************
* Author: Colin Boblet
* Section: Wednesday
*****************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include <shapes.h>
#include <fontinfo.h>
#include <math.h>
#include <wiringPiI2C.h>
#include "draw.h"

/* 
 * This function draws the background of the oscilloscope. 
 * It takes in the width and height of the screen. There are 
 * 5 y divisions and 10 x divisions.
 */
void drawlines(int width, int height){
  // Variables to hold the interval between x and y division lines
  int xdiv, ydiv;
  xdiv = width/10;
  ydiv = height/5;
  
  // Draw the background color of the screen
  Background(0,0,0);
  
  // Set the line color transparency and width
  Stroke(128,128,128,0.5);
  StrokeWidth(4);
  
  // Draw the x and y division lines
  for(int i = 0; i<=10; i++){
    Line(i*xdiv,0,i*xdiv,height);
  }
  for(int i = 0; i<=5; i++){
    Line(0,i*ydiv,width,i*ydiv);
  }
}

/* 
 * This function draws data on the screen. This function takes in the 
 * screen width height, x scale in ms, y scale in mV, sample rate in 
 * ksamples per second, data array, line color, vertical offset, and 
 * number of data points needed
 */
void drawdata(int width, int height, int xscale, int yscale, int samplerate, int data[1000001], int color[4], int offset, int datacount){
  
  // These are temporary variables for holding the x position of the data points
  int x1, x2;
  int xdiv;
  
  // Scale  the y scale so the minimum value is 1
  yscale = yscale/100;
  
  // Scale data from 0-255 to 0-height. The extra multiplication by 10 is to mitigate rounding errors
  for(int i = 0; i < datacount; i++){
    data[i]  = data[i] + offset*3 - 128*3;
    data[i] = (((data[i]*height*10)/255)/yscale) + offset*4 - 128*4;
  }
  
  // Set the line color and width
  Stroke(color[0],color[1],color[2],color[3]);
  StrokeWidth(4);
  
  // Draw the data points with lines between each data point
  for(int i = 0; i < (datacount-1); i++){
    x1 = (width*i)/(datacount-1);
    x2 = (width*(i+1))/(datacount-1);
    Line(x1, data[i], x2, data[i+1]);
  }
}

void printScaleSettings(int xscale, int yscale, int trigger, int channel, int level, int mode, int slope) {
  
  // Define array to hold messages to be printed
  char str[100];
  
  // Set the x position for all messages
  int xposition = 50;
  
  // Set the starting y positions
  int yposition = 1000;
  
  // Set the line color width and transparency
  VGfloat tcolor[4] = {0, 0, 255, 1};
  setfill(tcolor);
  
  // Print out the x scale in ms or us
  if (xscale >= 1000){
    sprintf(str, "X scale = %0d ms/div", xscale/1000);
  }
  else{
    sprintf(str, "X scale = %0d us/div", xscale);
  }
  Text(xposition, yposition, str, SansTypeface, 18);

  // Print the y scale in volts
  sprintf(str, "Y scale = %3.2f V/div", yscale * 0.25);
  Text(xposition, yposition-30, str, SansTypeface, 18);
  
  // If trigger is enabled print out the trigger settings
  if(mode){
    
    // Print trigger level
    sprintf(str, "Trigger level: %d mV", level*20);
    Text(xposition, yposition-60, str, SansTypeface, 18);
    
    // Print trigger channel
    sprintf(str, "Trigger channel: %d", channel);
    Text(xposition, yposition-90, str, SansTypeface, 18);
    
    // Print whether it is positive or negative edge triggered
    if(slope){
      sprintf(str, "Positive edge triggered");
      Text(xposition, yposition-120, str, SansTypeface, 18);
    }
    else{
      sprintf(str, "Negative edge triggered");
      Text(xposition, yposition-120, str, SansTypeface, 18);
    }
  }
  
  else{
    
    // Print if trigger is not enabled
    sprintf(str, "Free-running");
    Text(xposition, yposition-60, str, SansTypeface, 18);
  }
}
